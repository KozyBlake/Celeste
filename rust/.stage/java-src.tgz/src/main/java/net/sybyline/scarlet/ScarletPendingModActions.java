package net.sybyline.scarlet;

import java.io.File;
import java.io.Reader;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.sybyline.scarlet.util.MiscUtils;

public class ScarletPendingModActions
{

    static final Logger LOG = LoggerFactory.getLogger("Scarlet/PendingModActions");

    public ScarletPendingModActions(Scarlet scarlet, File pendingModActionsFile)
    {
        this.scarlet = scarlet;
        this.pendingModActionsFile = pendingModActionsFile;
        this.pendingModActions = new ConcurrentHashMap<>();
        this.pendingBanInfo = new ConcurrentHashMap<>();
        this.timedBans = new ConcurrentHashMap<>();
        this.load();
    }

    final Scarlet scarlet;
    final File pendingModActionsFile;
    final Map<String, String> pendingModActions;
    final Map<String, BanInfo> pendingBanInfo;
    // Users banned with an automatic expiry. Keyed by VRChat user id. Persisted so a
    // pending unban survives restarts (a 7-day ban must outlive the app being closed).
    final Map<String, TimedBan> timedBans;

    public static class DataSpec
    {
        public Map<String, String> pendingModActions;
        public Map<String, BanInfo> pendingBanInfo;
        public Map<String, TimedBan> timedBans;
    }
    public static class TimedBan
    {
        public TimedBan()
        {
        }
        public TimedBan(long expiresAt, String actorUserId)
        {
            this.expiresAt = expiresAt;
            this.actorUserId = actorUserId;
        }
        /** Epoch milliseconds at which the automatic unban becomes due. */
        public long expiresAt;
        /** VRChat user id of the moderator who set the ban, so the unban is attributed to them. */
        public String actorUserId;
    }
    public static class BanInfo
    {
        public BanInfo()
        {
        }
        public String ownerSnowflake;
        public String description;
        public String[] tags;
    }

    public boolean hasPending(GroupAuditType type, String targetUserId)
    {
        return this.pendingModActions.containsKey(type.id+":"+targetUserId);
    }

    public String addPending(GroupAuditType type, String targetUserId, String actorUserId)
    {
        String prevActorUserId = this.pendingModActions.putIfAbsent(type.id+":"+targetUserId, actorUserId);
        if (prevActorUserId == null)
        {
            this.save();
            // A moderation action was just initiated through Scarlet:
            // burst-poll the audit log so its Discord thread posts promptly
            // instead of waiting out the full audit polling interval.
            if (this.scarlet != null)
                this.scarlet.pollAuditSoon();
        }
        return prevActorUserId;
    }

    public String getPending(GroupAuditType type, String targetUserId)
    {
        return this.pendingModActions.get(type.id+":"+targetUserId);
    }

    public String pollPending(GroupAuditType type, String targetUserId)
    {
        String prevActorUserId = this.pendingModActions.remove(type.id+":"+targetUserId);
        if (prevActorUserId != null)
        {
            this.save();
            // All Scarlet-initiated actions have been observed in the audit
            // log; no need to keep burst polling.
            if (this.scarlet != null && this.pendingModActions.isEmpty())
                this.scarlet.endAuditFastPoll();
        }
        return prevActorUserId;
    }

    public boolean addBanInfo(String targetUserId)
    {
        return this.addBanInfo(targetUserId, null);
    }

    public boolean addBanInfo(String targetUserId, String ownerSnowflake)
    {
        BanInfo info = new BanInfo();
        info.ownerSnowflake = ownerSnowflake;
        if (this.pendingBanInfo.putIfAbsent(targetUserId, info) != null)
            return false;
        this.save();
        return true;
    }

    public boolean isBanInfoOwner(String targetUserId, String ownerSnowflake)
    {
        BanInfo info = this.pendingBanInfo.get(targetUserId);
        if (info == null)
            return false;
        return info.ownerSnowflake == null || info.ownerSnowflake.equals(ownerSnowflake);
    }

    public boolean setBanInfoTags(String targetUserId, String[] tags)
    {
        BanInfo info = this.pendingBanInfo.get(targetUserId);
        if (info == null)
            return false;
        info.tags = tags;
        this.save();
        return true;
    }

    public boolean setBanInfoDescription(String targetUserId, String description)
    {
        BanInfo info = this.pendingBanInfo.get(targetUserId);
        if (info == null)
            return false;
        info.description = description;
        this.save();
        return true;
    }

    public BanInfo pollBanInfo(String targetUserId)
    {
        BanInfo info = this.pendingBanInfo.remove(targetUserId);
        if (info != null)
            this.save();
        return info;
    }

    /** Record (or refresh) an automatic-unban timer for a banned user. */
    public void setTimedBan(String targetUserId, long expiresAt, String actorUserId)
    {
        this.timedBans.put(targetUserId, new TimedBan(expiresAt, actorUserId));
        this.save();
    }

    public TimedBan getTimedBan(String targetUserId)
    {
        return this.timedBans.get(targetUserId);
    }

    public boolean removeTimedBan(String targetUserId)
    {
        if (this.timedBans.remove(targetUserId) != null)
        {
            this.save();
            return true;
        }
        return false;
    }

    /** A stable copy for iteration by the expiry sweep. */
    public Map<String, TimedBan> timedBansSnapshot()
    {
        return new HashMap<>(this.timedBans);
    }

    public boolean load()
    {
        if (!this.pendingModActionsFile.isFile())
        {
            this.save();
            return true;
        }
        DataSpec spec;
        try (Reader r = MiscUtils.reader(this.pendingModActionsFile))
        {
            spec = Scarlet.GSON_PRETTY.fromJson(r, DataSpec.class);
        }
        catch (Exception ex)
        {
            LOG.error("Exception loading pending moderation actions", ex);
            return false;
        }
        this.pendingModActions.clear();
        if (spec != null && spec.pendingModActions != null && !spec.pendingModActions.isEmpty())
        {
            this.pendingModActions.putAll(spec.pendingModActions);
        }
        this.pendingBanInfo.clear();
        if (spec != null && spec.pendingBanInfo != null && !spec.pendingBanInfo.isEmpty())
        {
            this.pendingBanInfo.putAll(spec.pendingBanInfo);
        }
        this.timedBans.clear();
        if (spec != null && spec.timedBans != null && !spec.timedBans.isEmpty())
        {
            this.timedBans.putAll(spec.timedBans);
        }
        return true;
    }

    public boolean save()
    {
        DataSpec spec = new DataSpec();
        spec.pendingModActions = new HashMap<>(this.pendingModActions);
        spec.pendingBanInfo = new HashMap<>(this.pendingBanInfo);
        spec.timedBans = new HashMap<>(this.timedBans);
        try (Writer w = net.sybyline.scarlet.util.FileBackups.writer(this.pendingModActionsFile))
        {
            Scarlet.GSON_PRETTY.toJson(spec, DataSpec.class, w);
        }
        catch (Exception ex)
        {
            LOG.error("Exception saving pending moderation actions", ex);
            return false;
        }
        return true;
    }

}
