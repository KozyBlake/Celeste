package net.sybyline.scarlet;

import java.awt.BorderLayout;
import net.sybyline.scarlet.util.FileBackups;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.image.BufferedImage;
import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.NetworkInterface;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import net.sybyline.scarlet.util.HttpURLInputStream;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import io.github.vrchatapi.model.GroupAuditLogEntry;
import io.github.vrchatapi.model.User;

import net.sybyline.scarlet.util.ScarletToast;
import net.sybyline.scarlet.util.LinuxNotificationInstallDialogs;
import net.sybyline.scarlet.util.MiscUtils;
import net.sybyline.scarlet.util.Platform;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ScarletMobile implements Closeable
{
    static final Logger LOG = LoggerFactory.getLogger("Scarlet/Mobile");
    static final MediaType JSON_MEDIA_TYPE = MediaType.get("application/json; charset=utf-8");

    static final SecureRandom SECURE_RANDOM = new SecureRandom();
    static final OkHttpClient HTTP = new OkHttpClient.Builder()
        .connectTimeout(10L, TimeUnit.SECONDS)
        .readTimeout(15L, TimeUnit.SECONDS)
        .writeTimeout(15L, TimeUnit.SECONDS)
        .build();

    public enum Severity
    {
        INFO(0),
        WATCH(1),
        WARNING(2),
        CRITICAL(3);

        Severity(int priority)
        {
            this.priority = priority;
        }

        final int priority;
    }

    public enum NotificationType
    {
        WATCHED_USER_JOIN("watched_user_join", "Watched user joined"),
        WATCHED_GROUP_JOIN("watched_group_join", "Watched group joined"),
        WATCHED_AVATAR("watched_avatar", "Watched avatar detected"),
        VOTE_TO_KICK("vote_to_kick", "Vote-to-kick started"),
        MODERATION("moderation", "Moderation event"),
        STAFF("staff", "Staff movement"),
        NEW_PLAYER("new_player", "New player joined"),
        MIXED_CHARACTER_NAME("mixed_character_name", "Mixed-character name"),
        SUSPICIOUS_PRONOUNS("suspicious_pronouns", "Suspicious pronouns"),
        TEST("test", "Test notification");

        NotificationType(String id, String title)
        {
            this.id = id;
            this.title = title;
        }

        public final String id, title;

        static final Map<String, NotificationType> BY_ID = new HashMap<>();
        static
        {
            for (NotificationType type : values())
                BY_ID.put(type.id, type);
        }

        public static NotificationType of(String id)
        {
            return id == null ? null : BY_ID.get(id);
        }
    }

    /**
     * The default relay, run by the Scarlet fork maintainer, used to deliver mobile push to a
     * paired phone that is not on the operator's LAN.
     * <p>
     * This is a real third-party hop and is treated as one: it is used only after the operator
     * has enabled the mobile companion (off by default), paired a device, and explicitly
     * accepted the disclosure in {@link #ensureRelayConsent()}. Operators who would rather not
     * route through it can point {@code mobile_relay_endpoint} at their own server, or blank it
     * to use LAN and FCM delivery only.
     * <p>
     * <b>Note for anyone forking this repository:</b> this endpoint is not yours. If you
     * redistribute a build, change it to a host you control or blank it — otherwise your users'
     * moderation events are delivered to a server operated by someone else.
     * <p>
     * The relay currently receives event payloads in the clear. Encrypting them end-to-end from
     * the pairing secret is planned, and would reduce this to an opaque forwarder.
     *
     * @see #relayEndpoint()
     * @see #ensureRelayConsent()
     */
    static final String RELAY_ENDPOINT_DEFAULT = "https://peachpuff-swan-183728.hostingersite.com/scarlet/mobile/event";
    static final int DIRECT_PORT = 24892;
    static final int PAIRING_EXPIRES_MINUTES = 10;

    public ScarletMobile(Scarlet scarlet, File devicesFile)
    {
        this.scarlet = scarlet;
        this.devicesFile = devicesFile;
        this.state = new State();
        this.load();

        this.enabled = scarlet.settings.new FileValuedBoolean("mobile_enabled", "Mobile companion", false);
        this.minSeverity = scarlet.settings.new FileValuedEnum<>("mobile_min_severity", "Mobile minimum severity", Severity.WATCH);
        this.notifyWatchedUsers = scarlet.settings.new FileValuedBoolean("mobile_notify_watched_users", "Mobile: watched users", true);
        this.notifyWatchedGroups = scarlet.settings.new FileValuedBoolean("mobile_notify_watched_groups", "Mobile: watched groups", true);
        this.notifyWatchedAvatars = scarlet.settings.new FileValuedBoolean("mobile_notify_watched_avatars", "Mobile: watched avatars", true);
        this.notifyVotesToKick = scarlet.settings.new FileValuedBoolean("mobile_notify_votes_to_kick", "Mobile: votes-to-kick", true);
        this.notifyModeration = scarlet.settings.new FileValuedBoolean("mobile_notify_moderation", "Mobile: moderation", true);
        this.notifyStaff = scarlet.settings.new FileValuedBoolean("mobile_notify_staff", "Mobile: staff joins/leaves", false);
        this.notifyNewPlayers = scarlet.settings.new FileValuedBoolean("mobile_notify_new_players", "Mobile: new players", false);
        this.notifyMixedNames = scarlet.settings.new FileValuedBoolean("mobile_notify_mixed_character_names", "Mobile: mixed-character names", false);
        this.notifySuspiciousPronouns = scarlet.settings.new FileValuedBoolean("mobile_notify_suspicious_pronouns", "Mobile: suspicious pronouns", true);
        // Path to a Firebase service account JSON. When set, paired devices that registered an
        // FCM token are reachable anywhere, not just on the LAN. Empty by default, in which
        // case Scarlet falls back to the LAN stream and the relay.
        this.fcmServiceAccount_ = scarlet.settings.new FileValuedStringPattern("mobile_fcm_service_account", "Mobile FCM service account JSON", "", null, false);
        // Optional relay for off-network delivery. Defaults to the maintainer-run host, but is
        // not contacted until the operator accepts the disclosure; see RELAY_ENDPOINT_DEFAULT.
        // Must be an https URL; the value is validated again before use.
        this.relayEndpoint_ = scarlet.settings.new FileValuedStringPattern("mobile_relay_endpoint", "Mobile relay endpoint (optional, https)", RELAY_ENDPOINT_DEFAULT, "https://.+", false);
        this.createPairingQr = scarlet.settings.new FileValuedVoid("Create mobile pairing QR", "Create", this::showPairingQrDialog);
        this.sendTestNotification = scarlet.settings.new FileValuedVoid("Send mobile test notification", "Send", this::sendTestNotification);
        this.showDeliveryStatus = scarlet.settings.new FileValuedVoid("Show mobile delivery status", "Show", this::showDeliveryStatusDialog);

        this.toastEnabled = scarlet.settings.new FileValuedBoolean("notify_desktop_enabled", "Desktop notifications", false);
        this.toastWatchedUsers = scarlet.settings.new FileValuedBoolean("toast_notify_watched_users", "Toast: watched users", true);
        this.toastWatchedGroups = scarlet.settings.new FileValuedBoolean("toast_notify_watched_groups", "Toast: watched groups", true);
        this.toastWatchedAvatars = scarlet.settings.new FileValuedBoolean("toast_notify_watched_avatars", "Toast: watched avatars", true);
        this.toastVotesToKick = scarlet.settings.new FileValuedBoolean("toast_notify_votes_to_kick", "Toast: votes-to-kick", true);
        this.toastModeration = scarlet.settings.new FileValuedBoolean("toast_notify_moderation", "Toast: moderation", true);
        this.toastStaff = scarlet.settings.new FileValuedBoolean("toast_notify_staff", "Toast: staff joins/leaves", false);
        this.toastNewPlayers = scarlet.settings.new FileValuedBoolean("toast_notify_new_players", "Toast: new players", false);
        this.toastMixedNames = scarlet.settings.new FileValuedBoolean("toast_notify_mixed_character_names", "Toast: mixed-character names", false);
        this.toastSuspiciousPronouns = scarlet.settings.new FileValuedBoolean("toast_notify_suspicious_pronouns", "Toast: suspicious pronouns", true);
        this.sendToastTest = scarlet.settings.new FileValuedVoid("Send desktop test notification", "Send", this::sendToastTest);
    }

    final Scarlet scarlet;
    final File devicesFile;
    State state;

    final ScarletSettings.FileValued<Boolean> enabled,
                                            notifyWatchedUsers,
                                            notifyWatchedGroups,
                                            notifyWatchedAvatars,
                                            notifyVotesToKick,
                                            notifyModeration,
                                            notifyStaff,
                                            notifyNewPlayers,
                                            notifyMixedNames,
                                            notifySuspiciousPronouns,
                                            toastEnabled,
                                            toastWatchedUsers,
                                            toastWatchedGroups,
                                            toastWatchedAvatars,
                                            toastVotesToKick,
                                            toastModeration,
                                            toastStaff,
                                            toastNewPlayers,
                                            toastMixedNames,
                                            toastSuspiciousPronouns;
    final ScarletSettings.FileValued<Severity> minSeverity;
    final ScarletSettings.FileValued<String> fcmServiceAccount_, relayEndpoint_;
    final ScarletSettings.FileValued<Void> createPairingQr, sendTestNotification, sendToastTest, showDeliveryStatus;
    HttpServer directServer;
    int directServerPort;
    final List<DirectClient> directClients = Collections.synchronizedList(new ArrayList<>());
    volatile FcmServiceAccount fcmServiceAccount;
    Device cachedRelayDevice;
    volatile String fcmAccessToken;
    volatile long fcmAccessTokenExpiresAtMillis;
    final AtomicBoolean toastInstallPrompted = new AtomicBoolean(false);
    /** Guards the one-time "relay configured but not consented" warning on the delivery path. */
    final AtomicBoolean relayConsentWarned = new AtomicBoolean(false);

    final AtomicInteger threadIdx = new AtomicInteger();

    /**
     * Threads for the direct LAN server. Each connected phone holds one for the whole life of
     * its event stream, so this pool must grow on demand and must never be Scarlet's shared
     * worker pool — otherwise a handful of paired phones starves audit polling outright.
     */
    final ExecutorService directServerExec = Executors.newCachedThreadPool(runnable ->
    {
        Thread thread = new Thread(runnable, "KozyBlake/Scarlet Mobile Direct Thread " + this.threadIdx.incrementAndGet());
        thread.setDaemon(true);
        return thread;
    });

    /**
     * Threads for outbound notification delivery (relay, FCM, webhooks) and retry scheduling.
     * Separate from Scarlet's worker pool so that a slow or unreachable endpoint — with up to
     * 10s connect plus 15s read timeout per attempt — delays only other notifications, never
     * moderation polling.
     */
    final ScheduledExecutorService notifyExec = Executors.newScheduledThreadPool(2, runnable ->
    {
        Thread thread = new Thread(runnable, "KozyBlake/Scarlet Mobile Notify Thread " + this.threadIdx.incrementAndGet());
        thread.setDaemon(true);
        return thread;
    });

    public boolean wants(NotificationType type, Severity severity)
    {
        return this.enabled.get()
            && this.defaultEnabled(type)
            && severity.priority >= this.minSeverity.get().priority;
    }

    void settingsLoaded()
    {
        this.ensureDirectServer();
    }

    public void notifyWatchedUserJoined(String displayName, String userId, ScarletWatchedEntities.WatchedEntity watchedUser, String location)
    {
        Severity severity = severityOf(watchedUser);
        this.emit(NotificationType.WATCHED_USER_JOIN, severity,
            severity == Severity.CRITICAL ? "Critical watched user joined" : "Watched user joined",
            nonBlank(watchedUser.message, displayName + " joined the instance"),
            location,
            event ->
            {
                event.subjectId = userId;
                event.subjectName = displayName;
                event.data.addProperty("watchType", watchedUser.type == null ? null : watchedUser.type.name());
                event.data.addProperty("critical", watchedUser.critical);
                event.data.addProperty("priority", watchedUser.priority);
            });
    }

    public void notifyWatchedGroupJoined(String displayName, String userId, ScarletWatchedGroups.WatchedGroup watchedGroup, String location)
    {
        Severity severity = severityOf(watchedGroup);
        this.emit(NotificationType.WATCHED_GROUP_JOIN, severity,
            severity == Severity.CRITICAL ? "Critical watched group joined" : "Watched group joined",
            displayName + " matched watched group: " + nonBlank(watchedGroup.message, watchedGroup.id),
            location,
            event ->
            {
                event.subjectId = userId;
                event.subjectName = displayName;
                event.data.addProperty("groupId", watchedGroup.id);
                event.data.addProperty("watchType", watchedGroup.type == null ? null : watchedGroup.type.name());
                event.data.addProperty("critical", watchedGroup.critical);
                event.data.addProperty("priority", watchedGroup.priority);
            });
    }

    public void notifyWatchedAvatar(String displayName, String userId, String avatarDisplayName, String[] potentialIds, ScarletWatchedEntities.WatchedEntity watchedAvatar, String location)
    {
        Severity severity = severityOf(watchedAvatar);
        this.emit(NotificationType.WATCHED_AVATAR, severity,
            severity == Severity.CRITICAL ? "Critical watched avatar detected" : "Watched avatar detected",
            displayName + " may be wearing " + nonBlank(avatarDisplayName, "a watched avatar"),
            location,
            event ->
            {
                event.subjectId = userId;
                event.subjectName = displayName;
                event.data.addProperty("avatarName", avatarDisplayName);
                event.data.addProperty("watchId", watchedAvatar.id);
                event.data.addProperty("watchMessage", watchedAvatar.message);
                event.data.add("potentialAvatarIds", Scarlet.GSON.toJsonTree(potentialIds == null ? new String[0] : potentialIds, String[].class));
                event.data.addProperty("critical", watchedAvatar.critical);
                event.data.addProperty("priority", watchedAvatar.priority);
            });
    }

    public void notifyVoteToKick(String targetDisplayName, String targetUserId, String actorDisplayName, String actorUserId, String location)
    {
        String body = actorDisplayName == null
            ? "A vote-to-kick was started against " + targetDisplayName
            : actorDisplayName + " started a vote-to-kick against " + targetDisplayName;
        this.emit(NotificationType.VOTE_TO_KICK, Severity.WARNING, "Vote-to-kick started", body, location, event ->
        {
            event.subjectId = targetUserId;
            event.subjectName = targetDisplayName;
            event.data.addProperty("actorId", actorUserId);
            event.data.addProperty("actorName", actorDisplayName);
        });
    }

    public void notifyStaffJoined(String displayName, String userId, String location)
    {
        this.emit(NotificationType.STAFF, Severity.INFO, "Staff joined", displayName + " joined the instance", location, event ->
        {
            event.subjectId = userId;
            event.subjectName = displayName;
            event.data.addProperty("direction", "join");
        });
    }

    public void notifyStaffLeft(String displayName, String userId, String location)
    {
        this.emit(NotificationType.STAFF, Severity.INFO, "Staff left", displayName + " left the instance", location, event ->
        {
            event.subjectId = userId;
            event.subjectName = displayName;
            event.data.addProperty("direction", "leave");
        });
    }

    public void notifyNewPlayerJoined(String displayName, String userId, long accountAgeDays, String location)
    {
        this.emit(NotificationType.NEW_PLAYER, Severity.WATCH, "New VRChat account joined",
            displayName + " joined VRChat " + accountAgeDays + " day(s) ago", location, event ->
            {
                event.subjectId = userId;
                event.subjectName = displayName;
                event.data.addProperty("accountAgeDays", accountAgeDays);
            });
    }

    public void notifyMixedCharacterName(String displayName, String userId, String location)
    {
        this.emit(NotificationType.MIXED_CHARACTER_NAME, Severity.WATCH, "Mixed-character name",
            displayName + " has a suspicious mixed-character name", location, event ->
            {
                event.subjectId = userId;
                event.subjectName = displayName;
            });
    }

    public void notifySuspiciousPronouns(String displayName, String userId, String pronouns, String reason, String location)
    {
        this.emit(NotificationType.SUSPICIOUS_PRONOUNS, Severity.WARNING, "Suspicious pronouns",
            displayName + ": " + pronouns + " (" + reason + ")", location, event ->
            {
                event.subjectId = userId;
                event.subjectName = displayName;
                event.data.addProperty("pronouns", pronouns);
                event.data.addProperty("reason", reason);
            });
    }

    public void notifyModeration(ScarletData.AuditEntryMetadata entryMeta, User actor, User target)
    {
        if (entryMeta == null || entryMeta.entry == null)
            return;
        GroupAuditLogEntry entry = entryMeta.entry;
        GroupAuditType type = GroupAuditType.of(entry.getEventType());
        String typeTitle = type == null ? GroupAuditType.title(entry.getEventType()) : type.title;
        String targetName = target != null ? target.getDisplayName() : entry.getTargetId();
        String actorName = actor != null ? actor.getDisplayName() : entryMeta.hasAuxActor() ? entryMeta.auxActorDisplayName : entry.getActorDisplayName();
        Severity severity = severityForModeration(entry.getEventType());
        this.emit(NotificationType.MODERATION, severity, typeTitle,
            typeTitle + " for " + targetName + " by " + nonBlank(actorName, "unknown actor"),
            null,
            event ->
            {
                event.subjectId = entry.getTargetId();
                event.subjectName = targetName;
                event.data.addProperty("auditId", entry.getId());
                event.data.addProperty("auditType", entry.getEventType());
                event.data.addProperty("actorId", entryMeta.hasAuxActor() ? entryMeta.auxActorId : entry.getActorId());
                event.data.addProperty("actorName", actorName);
                event.data.addProperty("description", entry.getDescription());
            });
    }

    void sendTestNotification()
    {
        this.emit(NotificationType.TEST, Severity.INFO, "Scarlet mobile test", "Scarlet can reach a paired mobile companion.", null, event ->
        {
            event.data.addProperty("manual", true);
        });
    }

    void emit(NotificationType type, Severity severity, String title, String body, String location, EventEditor editor)
    {
        // Desktop toasts fire independently of the mobile companion (own toggles), so this runs
        // before the mobile gate below. emit() is only reached for live joins, so no load flood.
        this.maybeToast(type, title, body);
        if (type != NotificationType.TEST && !this.wants(type, severity))
            return;
        if (type == NotificationType.TEST && !this.enabled.get())
        {
            this.info("Mobile companion is disabled", "Enable Mobile companion before sending a test notification.");
            return;
        }

        MobileEvent event = new MobileEvent();
        event.id = UUID.randomUUID().toString();
        event.type = type.id;
        event.typeTitle = type.title;
        event.severity = severity.name();
        event.title = title;
        event.body = body;
        event.location = location;
        event.timestamp = OffsetDateTime.now(ZoneOffset.UTC);
        event.app = Scarlet.APP_NAME;
        event.appVersion = Scarlet.VERSION;
        event.instanceId = this.state.instanceId;
        if (this.scarlet.vrc != null)
            event.groupId = this.scarlet.vrc.groupId;
        event.data = new JsonObject();
        if (editor != null)
            editor.edit(event);

        this.dispatch(event);
    }

    /**
     * Fans an event out to every delivery path.
     * <p>
     * The LAN broadcast is now only a queue offer, so it returns immediately and runs inline.
     * Each remote endpoint is submitted as its own task rather than posted in a loop: a single
     * unreachable endpoint can burn 25 seconds in connect and read timeouts, and sequentially
     * that delay was inherited by every device behind it in the list.
     */
    void dispatch(MobileEvent event)
    {
        // The caller is typically the VRChat log-tailing or audit-processing thread, which must
        // never wait on notification work, so the fan-out itself is handed to the notify pool.
        this.submitDelivery(() -> this.dispatch0(event));
    }

    void dispatch0(MobileEvent event)
    {
        // Broadcast to any LAN SSE clients (low latency on same network). Non-blocking.
        this.broadcastDirect(event);

        // Always also post to relay — LAN may appear alive due to TCP buffering
        // even after the phone has left the network. Android deduplicates by
        // notification tag (event ID hash) so no duplicate alerts appear.
        // Consent is checked here rather than only at pairing so that blanking or repointing the
        // endpoint takes effect immediately, without needing to re-pair.
        String relayEndpoint = this.relayConsentGranted() ? this.relayEndpoint() : null;
        // Devices paired before the disclosure existed still have a relay secret but no recorded
        // consent, so relay delivery stops until they accept it. Say so once, loudly: an alert
        // that silently stops arriving on someone's phone is worse than one that never worked.
        if (relayEndpoint == null && this.relayEndpoint() != null && this.relayDevice() != null
            && this.relayConsentWarned.compareAndSet(false, true))
            LOG.warn("A relay is configured and a device is paired, but the relay disclosure has "
                + "not been accepted, so off-network mobile alerts are not being sent. Open "
                + "Settings -> \"Create mobile pairing QR\" to review and accept it.");
        Device relayDevice = relayEndpoint == null ? null : this.relayDevice();
        if (relayDevice != null)
            this.submitDelivery(() -> this.postEvent(relayEndpoint, relayDevice, event));

        // Also handle any registered FCM/webhook devices
        List<Device> devices;
        synchronized (this)
        {
            devices = new ArrayList<>(this.state.devices);
        }
        NotificationType type = NotificationType.of(event.type);
        for (Device device : devices)
        {
            if (device == null || !device.enabled)
                continue;
            if (type != null && !device.wants(type, true))
                continue;
            if (clean(device.pushToken) != null && this.isFcmConfigured())
            {
                this.submitDelivery(() -> this.postFcm(device, event));
                continue;
            }
            String endpoint = clean(device.pushEndpoint);
            if (endpoint == null)
            {
                // No push endpoint and no usable FCM configuration: this device has no way to
                // be reached. Record it so the cause is visible in the UI rather than silent.
                this.markFailed(device, this.isFcmConfigured()
                    ? "no push endpoint"
                    : "no push endpoint, and FCM is not configured");
                continue;
            }
            this.submitDelivery(() -> this.postEvent(endpoint, device, event));
        }
    }

    void submitDelivery(Runnable task)
    {
        try
        {
            this.notifyExec.execute(task);
        }
        catch (Exception ex)
        {
            LOG.debug("Could not submit mobile delivery task", ex);
        }
    }

    /**
     * The operator-configured relay endpoint, or {@code null} when relay delivery is not set up.
     * <p>
     * Kept cheap: this runs on the delivery path for every event, so it does no DNS resolution.
     * The stricter public-address check is done once at pairing time by
     * {@link #relayEndpointForPairing()}, where latency does not matter.
     */
    String relayEndpoint()
    {
        String endpoint = clean(this.relayEndpoint_.get());
        if (endpoint == null)
            return null;
        if (!endpoint.regionMatches(true, 0, "https://", 0, 8))
        {
            LOG.warn("Ignoring mobile relay endpoint: must be an https URL");
            return null;
        }
        return endpoint;
    }

    /**
     * The relay endpoint to advertise in a pairing QR, or {@code null} if none is usable.
     * <p>
     * Also rejects private, loopback, link-local and metadata addresses, so a mistyped or
     * hostile value cannot turn a paired phone into a probe against the operator's own network.
     */
    String relayEndpointForPairing()
    {
        String endpoint = this.relayEndpoint();
        if (endpoint == null)
            return null;
        if (!HttpURLInputStream.PUBLIC_ONLY.test(endpoint))
        {
            LOG.warn("Ignoring mobile relay endpoint: does not resolve to a public address");
            return null;
        }
        return endpoint;
    }

    /**
     * Whether the operator has accepted the disclosure for the currently configured relay.
     * <p>
     * Cheap and allocation-free enough to sit on the per-event delivery path.
     */
    boolean relayConsentGranted()
    {
        String endpoint = this.relayEndpoint();
        if (endpoint == null)
            return false;
        synchronized (this)
        {
            return Objects.equals(endpoint, this.state.relayConsentEndpoint);
        }
    }

    /**
     * Asks the operator, once per distinct relay endpoint, whether moderation events may be
     * routed through that host — naming the host and the fields it will receive.
     * <p>
     * Called at pairing time, which is the point the relay first becomes reachable. Declining
     * is not an error: pairing continues over the LAN and FCM, and the QR simply advertises no
     * relay. On a headless host there is no one to prompt, so the disclosure is logged and the
     * relay stays disabled until an operator accepts it in the desktop UI — silence is not
     * consent.
     *
     * @return whether the relay may be used
     */
    boolean ensureRelayConsent()
    {
        String endpoint = this.relayEndpoint();
        if (endpoint == null)
            return false;
        if (this.relayConsentGranted())
            return true;

        String host;
        try
        {
            host = URI.create(endpoint).getHost();
        }
        catch (Exception ex)
        {
            host = endpoint;
        }

        String message =
            "Scarlet can deliver mobile alerts to your phone when it is not on this network by\n" +
            "relaying them through:\n\n" +
            "    " + host + "\n\n" +
            "This is a third-party server. If you enable it, each alert sent to your phone is\n" +
            "delivered through that host, and includes:\n\n" +
            "  • the VRChat user ID and display name the alert is about\n" +
            "  • your group ID, and the instance/world the event happened in\n" +
            "  • the alert title and text, and its severity\n\n" +
            "It does NOT include your VRChat or Discord credentials, session tokens, or any\n" +
            "file from this machine. Alerts are sent over HTTPS, but are not currently\n" +
            "end-to-end encrypted, so the relay operator is technically able to read them.\n\n" +
            "You can decline and still use the mobile companion over your local network, or\n" +
            "point Settings → \"Mobile relay endpoint\" at a server you run yourself.\n\n" +
            "Route mobile alerts through this relay?";

        if (GraphicsEnvironment.isHeadless())
        {
            LOG.warn("Mobile relay {} not used: it requires consent, and this host is headless. "
                + "Accept it in the desktop UI, set mobile_relay_endpoint to your own server, "
                + "or leave it blank to use LAN/FCM delivery only.", host);
            return false;
        }

        if (!this.scarlet.settings.requireConfirmYesNo(message, "Scarlet mobile relay"))
        {
            LOG.info("Operator declined the mobile relay; using LAN/FCM delivery only");
            return false;
        }

        synchronized (this)
        {
            this.state.relayConsentEndpoint = endpoint;
            this.save();
        }
        LOG.info("Operator accepted the mobile relay {}", host);
        return true;
    }

    /**
     * The relay's pseudo-device, reused across dispatches so its delivery status survives.
     * Rebuilt whenever the pairing secret changes.
     */
    synchronized Device relayDevice()
    {
        String relaySecret = clean(this.state.relaySecret);
        if (relaySecret == null)
            return null;
        Device relay = this.cachedRelayDevice;
        if (relay == null || !Objects.equals(relay.authToken, relaySecret))
        {
            relay = new Device();
            relay.id = "relay";
            relay.name = "Relay";
            relay.authToken = relaySecret;
            this.cachedRelayDevice = relay;
        }
        return relay;
    }

    /** Path to the Firebase service account JSON, or null if the user has not set one. */
    String fcmServiceAccountPath()
    {
        return clean(this.fcmServiceAccount_.get());
    }

    boolean isFcmConfigured()
    {
        String file = this.fcmServiceAccountPath();
        return file != null && new File(file).isFile();
    }

    void postFcm(Device device, MobileEvent event)
    {
        this.postFcm(device, event, 1);
    }

    void postFcm(Device device, MobileEvent event, int attempt)
    {
        try
        {
            FcmServiceAccount account = this.loadFcmServiceAccount();
            if (account == null)
            {
                this.markFailed(device, "FCM service account could not be loaded");
                return;
            }

            JsonObject message = new JsonObject();
            JsonObject root = new JsonObject();
            JsonObject notification = new JsonObject();
            JsonObject data = new JsonObject();
            JsonObject android = new JsonObject();
            JsonObject androidNotification = new JsonObject();

            notification.addProperty("title", nonBlank(event.title, "Scarlet alert"));
            notification.addProperty("body", nonBlank(event.body, "Scarlet sent an alert."));
            data.addProperty("eventId", event.id);
            data.addProperty("type", event.type);
            data.addProperty("severity", event.severity);
            data.addProperty("title", nonBlank(event.title, "Scarlet alert"));
            data.addProperty("body", nonBlank(event.body, "Scarlet sent an alert."));
            data.addProperty("instanceId", event.instanceId);
            data.addProperty("groupId", event.groupId);
            data.addProperty("location", event.location);
            data.addProperty("subjectId", event.subjectId);
            data.addProperty("subjectName", event.subjectName);
            android.addProperty("priority", "high");
            androidNotification.addProperty("channel_id", "scarlet_alerts");
            androidNotification.addProperty("tag", nonBlank(event.id, event.type));
            android.add("notification", androidNotification);
            message.addProperty("token", device.pushToken);
            message.add("notification", notification);
            message.add("data", data);
            message.add("android", android);
            root.add("message", message);

            Request request = new Request.Builder()
                .url("https://fcm.googleapis.com/v1/projects/" + account.projectId + "/messages:send")
                .post(RequestBody.create(JSON_MEDIA_TYPE, Scarlet.GSON.toJson(root)))
                .header("Authorization", "Bearer " + this.getFcmAccessToken(account))
                .header("Content-Type", "application/json; charset=utf-8")
                .build();

            try (Response response = HTTP.newCall(request).execute())
            {
                if (response.isSuccessful())
                {
                    this.markDelivered(device);
                    if (NotificationType.TEST.id.equals(event.type))
                        this.info("Mobile test sent", "Scarlet sent a test notification through Firebase Cloud Messaging.");
                    return;
                }
                int code = response.code();
                LOG.warn("FCM returned HTTP {} for mobile event {} (attempt {}/{})", code, event.id, attempt, DELIVERY_MAX_ATTEMPTS);
                this.markFailed(device, "FCM HTTP " + code);
                // 401 usually means the cached OAuth token went stale; drop it so the retry
                // mints a fresh one. 404/UNREGISTERED means the app was uninstalled — permanent.
                if (code == 401)
                    this.invalidateFcmAccessToken();
                if ((code == 401 || code == 429 || code >= 500) && this.scheduleFcmRetry(device, event, attempt))
                    return;
                if (NotificationType.TEST.id.equals(event.type))
                    this.info("Mobile test failed", "Firebase Cloud Messaging returned HTTP " + code + ".");
            }
        }
        catch (Exception ex)
        {
            LOG.warn("Exception sending mobile event {} through FCM (attempt {}/{})", event.id, attempt, DELIVERY_MAX_ATTEMPTS, ex);
            this.markFailed(device, ex.getMessage());
            if (this.scheduleFcmRetry(device, event, attempt))
                return;
            if (NotificationType.TEST.id.equals(event.type))
                this.info("Mobile test failed", ex.getMessage());
        }
    }

    synchronized void invalidateFcmAccessToken()
    {
        this.fcmAccessToken = null;
        this.fcmAccessTokenExpiresAtMillis = 0L;
    }

    boolean scheduleFcmRetry(Device device, MobileEvent event, int attempt)
    {
        if (attempt >= DELIVERY_MAX_ATTEMPTS)
        {
            LOG.warn("Giving up on mobile event {} through FCM after {} attempts", event.id, attempt);
            return false;
        }
        long delay = DELIVERY_RETRY_BACKOFF_MILLIS[Math.min(attempt - 1, DELIVERY_RETRY_BACKOFF_MILLIS.length - 1)];
        try
        {
            this.notifyExec.schedule(() -> this.postFcm(device, event, attempt + 1), delay, TimeUnit.MILLISECONDS);
            return true;
        }
        catch (Exception ex)
        {
            LOG.debug("Could not schedule FCM retry for event {}", event.id, ex);
            return false;
        }
    }

    synchronized FcmServiceAccount loadFcmServiceAccount()
    {
        String file = this.fcmServiceAccountPath();
        if (file == null)
            return null;
        FcmServiceAccount cached = this.fcmServiceAccount;
        if (cached != null && Objects.equals(cached.file, file))
            return cached;
        try (FileReader reader = new FileReader(file))
        {
            JsonObject json = Scarlet.GSON.fromJson(reader, JsonObject.class);
            FcmServiceAccount account = new FcmServiceAccount();
            account.file = file;
            account.projectId = stringMember(json, "project_id");
            account.clientEmail = stringMember(json, "client_email");
            account.privateKeyPem = stringMember(json, "private_key");
            if (clean(account.projectId) == null || clean(account.clientEmail) == null || clean(account.privateKeyPem) == null)
                throw new IllegalArgumentException("Service account JSON must include project_id, client_email, and private_key");
            this.fcmServiceAccount = account;
            this.fcmAccessToken = null;
            this.fcmAccessTokenExpiresAtMillis = 0L;
            return account;
        }
        catch (Exception ex)
        {
            LOG.warn("Exception loading mobile FCM service account JSON", ex);
            return null;
        }
    }

    synchronized String getFcmAccessToken(FcmServiceAccount account) throws Exception
    {
        long nowMillis = System.currentTimeMillis();
        if (this.fcmAccessToken != null && this.fcmAccessTokenExpiresAtMillis - 60_000L > nowMillis)
            return this.fcmAccessToken;

        long nowSeconds = nowMillis / 1000L;
        JsonObject header = new JsonObject();
        header.addProperty("alg", "RS256");
        header.addProperty("typ", "JWT");
        JsonObject claim = new JsonObject();
        claim.addProperty("iss", account.clientEmail);
        claim.addProperty("scope", "https://www.googleapis.com/auth/firebase.messaging");
        claim.addProperty("aud", "https://oauth2.googleapis.com/token");
        claim.addProperty("iat", nowSeconds);
        claim.addProperty("exp", nowSeconds + 3600L);
        String unsignedJwt = base64Url(Scarlet.GSON.toJson(header).getBytes(StandardCharsets.UTF_8))
            + "."
            + base64Url(Scarlet.GSON.toJson(claim).getBytes(StandardCharsets.UTF_8));
        String jwt = unsignedJwt + "." + base64Url(signRsaSha256(account.privateKeyPem, unsignedJwt));

        String form = "grant_type=" + urlEncode("urn:ietf:params:oauth:grant-type:jwt-bearer")
            + "&assertion=" + urlEncode(jwt);
        Request request = new Request.Builder()
            .url("https://oauth2.googleapis.com/token")
            .post(RequestBody.create(MediaType.get("application/x-www-form-urlencoded; charset=utf-8"), form))
            .build();
        try (Response response = HTTP.newCall(request).execute())
        {
            String body = response.body() == null ? "" : response.body().string();
            if (!response.isSuccessful())
                throw new IllegalStateException("OAuth token request failed: HTTP " + response.code() + " " + body);
            JsonObject json = Scarlet.GSON.fromJson(body, JsonObject.class);
            this.fcmAccessToken = stringMember(json, "access_token");
            long expiresIn = json != null && json.has("expires_in") ? json.get("expires_in").getAsLong() : 3600L;
            this.fcmAccessTokenExpiresAtMillis = nowMillis + (expiresIn * 1000L);
            return this.fcmAccessToken;
        }
    }

    int broadcastDirect(MobileEvent event)
    {
        if (!this.enabled.get())
            return 0;
        this.ensureDirectServer();
        String data = Scarlet.GSON.toJson(event, MobileEvent.class);
        int sent = 0;
        List<DirectClient> snapshot;
        synchronized (this.directClients)
        {
            snapshot = new ArrayList<>(this.directClients);
        }
        for (DirectClient client : snapshot)
        {
            if (client.send(data))
                sent++;
        }
        return sent;
    }

    /** Delivery attempts (including the first) before an event is given up on. */
    static final int DELIVERY_MAX_ATTEMPTS = 5;
    /** Backoff before each retry. A phone or relay blip of a few seconds no longer loses an alert. */
    static final long[] DELIVERY_RETRY_BACKOFF_MILLIS = { 2_000L, 5_000L, 15_000L, 45_000L };

    void postEvent(String endpoint, Device device, MobileEvent event)
    {
        this.postEvent(endpoint, device, event, 1);
    }

    /**
     * Posts an event, retrying with backoff on failure.
     * <p>
     * A single dropped POST used to lose the alert outright: the failure was logged and
     * discarded. Moderation alerts are exactly the kind of message that must not be lost to a
     * two-second network blip, so transient failures (I/O errors, HTTP 5xx, HTTP 429) are now
     * retried. Client errors other than 429 are permanent — a rejected auth token or an
     * unregistered push token will not start working — so those stop immediately.
     */
    void postEvent(String endpoint, Device device, MobileEvent event, int attempt)
    {
        JsonObject envelope = new JsonObject();
        envelope.addProperty("schema", 1);
        envelope.addProperty("kind", "scarlet-mobile-event");
        envelope.add("event", Scarlet.GSON.toJsonTree(event, MobileEvent.class));
        if (device != null)
        {
            envelope.addProperty("deviceId", device.id);
            envelope.addProperty("deviceName", device.name);
            envelope.addProperty("pushToken", device.pushToken);
        }
        String json = Scarlet.GSON.toJson(envelope);
        RequestBody body = RequestBody.create(JSON_MEDIA_TYPE, json);
        Request.Builder builder = new Request.Builder()
            .url(endpoint)
            .post(body)
            .header("X-Scarlet-Mobile", "1");
        String authToken = device != null && clean(device.authToken) != null
            ? device.authToken
            : null;
        if (authToken != null)
            builder.header("Authorization", "Bearer " + authToken.trim());

        try (Response response = HTTP.newCall(builder.build()).execute())
        {
            if (response.isSuccessful())
            {
                this.markDelivered(device);
                if (NotificationType.TEST.id.equals(event.type))
                    this.info("Mobile test sent", "Scarlet sent a test notification to the configured relay.");
                return;
            }
            int code = response.code();
            boolean transient_ = code == 429 || code >= 500;
            LOG.warn("Mobile relay returned HTTP {} for event {} (attempt {}/{})", code, event.id, attempt, DELIVERY_MAX_ATTEMPTS);
            this.markFailed(device, "HTTP " + code);
            if (transient_ && this.scheduleRetry(endpoint, device, event, attempt))
                return;
            if (NotificationType.TEST.id.equals(event.type))
                this.info("Mobile test failed", "The endpoint returned HTTP " + code + ".");
        }
        catch (Exception ex)
        {
            LOG.warn("Exception posting mobile event {} to {} (attempt {}/{})", event.id, endpoint, attempt, DELIVERY_MAX_ATTEMPTS, ex);
            this.markFailed(device, ex.getMessage());
            if (this.scheduleRetry(endpoint, device, event, attempt))
                return;
            if (NotificationType.TEST.id.equals(event.type))
                this.info("Mobile test failed", ex.getMessage());
        }
    }

    /**
     * Queues another delivery attempt if any remain. Returns whether a retry was scheduled, so
     * the caller can tell a "will try again" failure from a final one.
     */
    boolean scheduleRetry(String endpoint, Device device, MobileEvent event, int attempt)
    {
        if (attempt >= DELIVERY_MAX_ATTEMPTS)
        {
            LOG.warn("Giving up on mobile event {} to {} after {} attempts", event.id, endpoint, attempt);
            return false;
        }
        long delay = DELIVERY_RETRY_BACKOFF_MILLIS[Math.min(attempt - 1, DELIVERY_RETRY_BACKOFF_MILLIS.length - 1)];
        try
        {
            this.notifyExec.schedule(() -> this.postEvent(endpoint, device, event, attempt + 1), delay, TimeUnit.MILLISECONDS);
            return true;
        }
        catch (Exception ex)
        {
            // Executor shut down mid-retry (Scarlet closing): nothing left to do.
            LOG.debug("Could not schedule mobile delivery retry for event {}", event.id, ex);
            return false;
        }
    }

    void markDelivered(Device device)
    {
        if (device == null)
            return;
        device.lastDeliveredAtMillis = System.currentTimeMillis();
        device.lastError = null;
    }

    void markFailed(Device device, String error)
    {
        if (device == null)
            return;
        device.lastErrorAtMillis = System.currentTimeMillis();
        device.lastError = error == null ? "delivery failed" : error;
    }

    /**
     * @param allowRelay whether the relay may be advertised in the payload. Resolved by the
     *                   caller via {@link #ensureRelayConsent()}, deliberately outside this
     *                   method: consent can involve a modal dialog, and this method holds the
     *                   instance monitor that the delivery path also needs.
     */
    synchronized PairingPayload createPairingPayload(boolean allowRelay)
    {
        this.pruneExpiredPairings();
        List<String> directEventEndpoints = this.directEndpoints("events");
        List<String> directPairEndpoints = this.directEndpoints("pair");
        OffsetDateTime now = OffsetDateTime.now(ZoneOffset.UTC);
        String pairingId = randomToken(12);
        String pairingSecret = randomToken(32);
        PendingPairing pending = new PendingPairing();
        pending.pairingId = pairingId;
        pending.secretHash = sha256(pairingSecret);
        pending.createdAt = now;
        pending.expiresAt = now.plusMinutes(PAIRING_EXPIRES_MINUTES);
        this.state.pendingPairings.add(pending);
        this.state.relaySecret = pairingSecret;
        this.save();

        JsonObject payload = new JsonObject();
        payload.addProperty("schema", 1);
        payload.addProperty("kind", "scarlet-mobile-pairing");
        payload.addProperty("app", Scarlet.APP_NAME);
        payload.addProperty("version", Scarlet.VERSION);
        payload.addProperty("instanceId", this.state.instanceId);
        payload.addProperty("groupId", this.scarlet.vrc == null ? null : this.scarlet.vrc.groupId);
        payload.addProperty("direct", !directEventEndpoints.isEmpty());
        payload.addProperty("directToken", this.state.directToken);
        JsonArray directEndpointsJson = new JsonArray();
        for (String directEventEndpoint : directEventEndpoints)
            directEndpointsJson.add(directEventEndpoint);
        payload.add("directEventEndpoints", directEndpointsJson);
        payload.addProperty("directEventEndpoint", directEventEndpoints.isEmpty() ? null : directEventEndpoints.get(0));
        JsonArray directPairEndpointsJson = new JsonArray();
        for (String directPairEndpoint : directPairEndpoints)
            directPairEndpointsJson.add(directPairEndpoint);
        payload.add("directPairEndpoints", directPairEndpointsJson);
        payload.addProperty("directPairEndpoint", directPairEndpoints.isEmpty() ? null : directPairEndpoints.get(0));
        payload.addProperty("pairingId", pairingId);
        payload.addProperty("pairingSecret", pairingSecret);
        payload.addProperty("createdAt", DateTimeFormatter.ISO_OFFSET_DATE_TIME.format(pending.createdAt));
        String expiresAt = DateTimeFormatter.ISO_OFFSET_DATE_TIME.format(pending.expiresAt);
        payload.addProperty("expiresAt", expiresAt);
        // null when the relay is unconfigured, unreachable-by-policy, or the operator declined
        // the disclosure: the phone then pairs over the LAN or FCM, and no third-party host is
        // advertised in the QR at all.
        String relayEndpoint = allowRelay ? this.relayEndpointForPairing() : null;
        String authToken = null;
        // Omit the relay keys entirely rather than emitting JSON nulls: the companion treats an
        // absent relay as "LAN/FCM only", and a QR for an unconfigured relay should advertise
        // no host at all.
        if (relayEndpoint != null)
        {
            payload.addProperty("relayEndpoint", relayEndpoint);
            payload.addProperty("relayPairEndpoint", pairEndpointFor(relayEndpoint));
            payload.addProperty("relayEventEndpoint", relayEventEndpointFor(relayEndpoint, this.state.instanceId));
        }
        payload.add("notificationDefaults", this.notificationDefaultsJson());
        if (authToken != null)
        {
            payload.addProperty("signature", hmacSha256Hex(authToken,
                pairingSignaturePayload(this.state.instanceId, pairingId, pairingSecret, expiresAt)));
        }

        PairingPayload result = new PairingPayload();
        result.pairingId = pairingId;
        result.expiresAt = pending.expiresAt;
        result.json = Scarlet.GSON_PRETTY.toJson(payload);
        return result;
    }

    public synchronized boolean registerDevice(String pairingId, String pairingSecret, Device device)
    {
        if (pairingId == null || pairingSecret == null || device == null)
            return false;
        this.pruneExpiredPairings();
        String hash = sha256(pairingSecret);
        Iterator<PendingPairing> iterator = this.state.pendingPairings.iterator();
        while (iterator.hasNext())
        {
            PendingPairing pending = iterator.next();
            if (Objects.equals(pairingId, pending.pairingId) && Objects.equals(hash, pending.secretHash))
            {
                iterator.remove();
                if (clean(device.id) == null)
                    device.id = "mob_" + randomToken(9);
                if (clean(device.name) == null)
                    device.name = "Android";
                device.enabled = true;
                device.pairedAt = OffsetDateTime.now(ZoneOffset.UTC);
                device.lastSeenAt = device.pairedAt;
                // Store pairingSecret as device auth token so event posts are authenticated
                // per-instance without any shared relay secret
                if (clean(device.authToken) == null)
                    device.authToken = pairingSecret;
                this.state.relaySecret = pairingSecret;
                this.state.devices.removeIf(existing -> existing != null && Objects.equals(existing.id, device.id));
                this.state.devices.add(device);
                this.save();
                return true;
            }
        }
        this.save();
        return false;
    }

    /**
     * Shows how each delivery path is actually doing.
     * <p>
     * A phone that quietly stops receiving alerts used to be entirely invisible: the desktop
     * kept "sending" into a dead socket and nothing in the UI disagreed. This makes the failure
     * legible — how many LAN streams are live, and when each device last took a notification.
     */
    void showDeliveryStatusDialog()
    {
        this.scarlet.execModal.execute(() ->
        {
            StringBuilder sb = new StringBuilder();

            sb.append("Mobile companion: ").append(this.enabled.get() ? "enabled" : "disabled").append('\n');
            sb.append("Minimum severity: ").append(this.minSeverity.get()).append('\n');

            HttpServer server = this.directServer;
            sb.append("Direct LAN listener: ");
            if (server == null)
                sb.append("not running");
            else
                sb.append("running on port ").append(this.directServerPort);
            sb.append('\n');

            List<DirectClient> clients;
            synchronized (this.directClients)
            {
                clients = new ArrayList<>(this.directClients);
            }
            sb.append("Live LAN event streams: ").append(clients.size()).append('\n');
            for (DirectClient client : clients)
                sb.append("    connected ").append(describeAge(client.connectedAtMillis)).append(" ago, ")
                  .append(client.queue.size()).append(" frame(s) queued\n");

            sb.append("FCM: ").append(this.isFcmConfigured()
                ? "configured (" + this.fcmServiceAccountPath() + ")"
                : "not configured").append('\n');

            Device relay = this.relayDevice();
            sb.append("Relay: ").append(relay == null ? "not paired" : relay.deliveryStatus()).append('\n');

            List<Device> devices;
            synchronized (this)
            {
                devices = new ArrayList<>(this.state.devices);
            }
            sb.append('\n').append("Paired devices: ").append(devices.size()).append('\n');
            for (Device device : devices)
            {
                if (device == null)
                    continue;
                sb.append('\n')
                  .append(nonBlank(device.name, "(unnamed)")).append("  [").append(nonBlank(device.platform, "?")).append("]\n")
                  .append("    ").append(device.enabled ? "enabled" : "DISABLED").append('\n')
                  .append("    transport: ").append(clean(device.pushToken) != null ? "FCM push token"
                      : clean(device.pushEndpoint) != null ? "webhook " + device.pushEndpoint
                      : "none — this device cannot be reached").append('\n')
                  .append("    ").append(device.deliveryStatus()).append('\n');
                if (device.pairedAt != null)
                    sb.append("    paired: ").append(DateTimeFormatter.ISO_OFFSET_DATE_TIME.format(device.pairedAt)).append('\n');
            }

            if (GraphicsEnvironment.isHeadless())
            {
                LOG.info("Mobile delivery status:\n{}", sb);
                return;
            }

            JTextArea text = new JTextArea(sb.toString(), 24, 62);
            text.setEditable(false);
            text.setCaretPosition(0);
            JPanel panel = new JPanel(new BorderLayout(8, 8));
            panel.add(new JScrollPane(text), BorderLayout.CENTER);
            panel.setPreferredSize(new Dimension(620, 480));
            JOptionPane.showMessageDialog(
                this.scarlet.ui == null ? null : this.scarlet.ui.getParentComponent(),
                panel,
                "Scarlet mobile delivery status",
                JOptionPane.INFORMATION_MESSAGE);
        });
    }

    void showPairingQrDialog()
    {
        this.scarlet.execModal.execute(() ->
        {
            // Prompted before createPairingPayload, which is synchronized: showing a modal while
            // holding that monitor would stall event delivery for as long as the dialog is open.
            boolean allowRelay = this.ensureRelayConsent();
            PairingPayload pairing = this.createPairingPayload(allowRelay);
            File png = new File(Scarlet.dir, "mobile_pairing_qr.png");
            try
            {
                this.writeQrPng(pairing.json, png, 420);
            }
            catch (Exception ex)
            {
                LOG.warn("Exception creating mobile pairing QR", ex);
                this.info("Mobile pairing QR failed", ex.getMessage());
                return;
            }

            if (GraphicsEnvironment.isHeadless())
            {
                LOG.info("Mobile pairing QR written to {}", png.getAbsolutePath());
                return;
            }

            JPanel panel = new JPanel(new BorderLayout(8, 8));
            try
            {
                panel.add(new JLabel(new ImageIcon(ImageIO.read(png))), BorderLayout.NORTH);
            }
            catch (Exception ex)
            {
                LOG.warn("Exception loading generated mobile pairing QR image", ex);
            }
            JTextArea text = new JTextArea(pairing.json, 7, 54);
            text.setLineWrap(true);
            text.setWrapStyleWord(true);
            text.setEditable(false);
            panel.add(new JScrollPane(text), BorderLayout.CENTER);
            JLabel footer = new JLabel("Expires: " + DateTimeFormatter.ISO_OFFSET_DATE_TIME.format(pairing.expiresAt) + "    File: " + png.getAbsolutePath());
            panel.add(footer, BorderLayout.SOUTH);
            panel.setPreferredSize(new Dimension(560, 620));

            Object[] options = {"Copy payload", "Open PNG", "Close"};
            int choice = JOptionPane.showOptionDialog(
                this.scarlet.ui.getParentComponent(),
                panel,
                "Scarlet mobile pairing",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                options,
                options[2]);
            if (choice == 0)
                Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(pairing.json), null);
            else if (choice == 1)
                MiscUtils.AWTDesktop.open(png);
        });
    }

    void writeQrPng(String payload, File file, int size) throws Exception
    {
        Map<EncodeHintType, Object> hints = new LinkedHashMap<>();
        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
        hints.put(EncodeHintType.MARGIN, Integer.valueOf(2));
        BitMatrix matrix = new MultiFormatWriter().encode(payload, BarcodeFormat.QR_CODE, size, size, hints);
        BufferedImage image = new BufferedImage(matrix.getWidth(), matrix.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D graphics = image.createGraphics();
        try
        {
            graphics.setColor(java.awt.Color.WHITE);
            graphics.fillRect(0, 0, image.getWidth(), image.getHeight());
            graphics.setColor(java.awt.Color.BLACK);
            for (int y = 0; y < matrix.getHeight(); y++)
                for (int x = 0; x < matrix.getWidth(); x++)
                    if (matrix.get(x, y))
                        graphics.fillRect(x, y, 1, 1);
        }
        finally
        {
            graphics.dispose();
        }
        ImageIO.write(image, "png", file);
    }

    JsonObject notificationDefaultsJson()
    {
        JsonObject json = new JsonObject();
        for (NotificationType type : NotificationType.values())
            json.addProperty(type.id, this.defaultEnabled(type));
        json.addProperty("minSeverity", this.minSeverity.get().name());
        return json;
    }

    boolean defaultEnabled(NotificationType type)
    {
        switch (type)
        {
        case WATCHED_USER_JOIN: return this.notifyWatchedUsers.get();
        case WATCHED_GROUP_JOIN: return this.notifyWatchedGroups.get();
        case WATCHED_AVATAR: return this.notifyWatchedAvatars.get();
        case VOTE_TO_KICK: return this.notifyVotesToKick.get();
        case MODERATION: return this.notifyModeration.get();
        case STAFF: return this.notifyStaff.get();
        case NEW_PLAYER: return this.notifyNewPlayers.get();
        case MIXED_CHARACTER_NAME: return this.notifyMixedNames.get();
        case SUSPICIOUS_PRONOUNS: return this.notifySuspiciousPronouns.get();
        case TEST: return true;
        default: return true;
        }
    }

    boolean toastEnabledFor(NotificationType type)
    {
        switch (type)
        {
        case WATCHED_USER_JOIN: return this.toastWatchedUsers.get();
        case WATCHED_GROUP_JOIN: return this.toastWatchedGroups.get();
        case WATCHED_AVATAR: return this.toastWatchedAvatars.get();
        case VOTE_TO_KICK: return this.toastVotesToKick.get();
        case MODERATION: return this.toastModeration.get();
        case STAFF: return this.toastStaff.get();
        case NEW_PLAYER: return this.toastNewPlayers.get();
        case MIXED_CHARACTER_NAME: return this.toastMixedNames.get();
        case SUSPICIOUS_PRONOUNS: return this.toastSuspiciousPronouns.get();
        case TEST: return true;
        default: return true;
        }
    }

    void maybeToast(NotificationType type, String title, String body)
    {
        if (type == NotificationType.TEST)
            return;
        if (!this.toastEnabled.get() || !this.toastEnabledFor(type))
            return;
        try
        {
            boolean ok = ScarletToast.show(title, body);
            if (!ok)
                this.promptLinuxNotifierInstall(false);
        }
        catch (Throwable ex)
        {
            LOG.debug("Desktop toast failed for {}", type, ex);
        }
    }

    void sendToastTest()
    {
        if (!this.toastEnabled.get())
        {
            this.info("Desktop notifications are disabled", "Enable Desktop notifications first.");
            return;
        }
        boolean ok = ScarletToast.show("Scarlet", "Desktop notifications are working.");
        if (!ok)
        {
            if (this.promptLinuxNotifierInstall(true))
                return;
            this.info("No desktop notifier available",
                "Scarlet could not find a way to show a desktop notification on this system. "
              + "On Linux, install 'notify-send' (the libnotify / libnotify-bin package).");
        }
    }

    boolean promptLinuxNotifierInstall(boolean userInitiated)
    {
        if (Platform.CURRENT != Platform.$NIX || Platform.isAndroid() || Platform.isTermux())
            return false;
        if (LinuxNotificationInstallDialogs.isNotifierInstalled())
        {
            if (!userInitiated && !this.toastInstallPrompted.compareAndSet(false, true))
                return true;
            if (userInitiated)
                this.info("Desktop notifier failed",
                    "Scarlet found notify-send, but the notification command failed. "
                  + "Make sure your desktop notification service and DBus session are running, "
                  + "and that notifications are not blocked or muted.");
            else
                LOG.warn("notify-send is installed, but the desktop notification command failed");
            return true;
        }
        if (!userInitiated && !this.toastInstallPrompted.compareAndSet(false, true))
            return true;

        this.scarlet.execModal.execute(() ->
        {
            Component parent = this.scarlet.ui == null ? null : this.scarlet.ui.getParentComponent();
            LinuxNotificationInstallDialogs.InstallDialogResult result =
                LinuxNotificationInstallDialogs.showInstallFlowIfNeeded(parent);
            if (result == LinuxNotificationInstallDialogs.InstallDialogResult.INSTALL_APPROVED_SUCCESS
             || result == LinuxNotificationInstallDialogs.InstallDialogResult.ALREADY_INSTALLED)
            {
                ScarletToast.resetAvailabilityCache();
                ScarletToast.show("Scarlet", "Desktop notifications are working.");
            }
        });
        return true;
    }

    void editDevicesFile()
    {
        synchronized (this)
        {
            this.save();
        }
        MiscUtils.AWTDesktop.edit(this.devicesFile);
    }

    synchronized void pruneExpiredPairings()
    {
        OffsetDateTime now = OffsetDateTime.now(ZoneOffset.UTC);
        this.state.pendingPairings.removeIf(pairing -> pairing == null || pairing.expiresAt == null || !pairing.expiresAt.isAfter(now));
    }

    synchronized boolean load()
    {
        if (!this.devicesFile.isFile())
        {
            this.state.instanceId = "scr_" + randomToken(12);
            this.state.directToken = randomToken(32);
            this.save();
            return true;
        }
        try
        {
            try (FileReader reader = new FileReader(this.devicesFile))
            {
                State loaded = Scarlet.GSON_PRETTY.fromJson(reader, State.class);
                if (loaded != null)
                    this.state = loaded;
            }
            if (clean(this.state.instanceId) == null)
                this.state.instanceId = "scr_" + randomToken(12);
            if (clean(this.state.directToken) == null)
                this.state.directToken = randomToken(32);
            if (this.state.devices == null)
                this.state.devices = new ArrayList<>();
            if (this.state.pendingPairings == null)
                this.state.pendingPairings = new ArrayList<>();
            this.pruneExpiredPairings();
            // Deliberately outside the reader's try-with-resources above. save() writes a temp
            // file and then moves it over the target, and Windows refuses to replace a file
            // that any handle is still open on — including this process's own read handle. So
            // saving while the reader was open failed on Windows every startup with "the
            // process cannot access the file because it is being used by another process",
            // while working fine on Linux, where POSIX permits renaming over an open file.
            this.save();
            return true;
        }
        catch (Exception ex)
        {
            LOG.warn("Exception loading mobile companion devices", ex);
            this.state = new State();
            this.state.instanceId = "scr_" + randomToken(12);
            this.state.directToken = randomToken(32);
            return false;
        }
    }

    synchronized boolean save()
    {
        try
        {
            File parent = this.devicesFile.getParentFile();
            if (parent != null && !parent.isDirectory())
                parent.mkdirs();
            try (java.io.Writer writer = FileBackups.writer(this.devicesFile))
            {
                Scarlet.GSON_PRETTY.toJson(this.state, State.class, writer);
            }
            return true;
        }
        catch (Exception ex)
        {
            LOG.warn("Exception saving mobile companion devices", ex);
            return false;
        }
    }

    @Override
    public void close()
    {
        this.stopDirectServer();
        // Both pools are daemon-threaded, so shutdownNow only hastens exit; pending retries
        // are abandoned deliberately rather than delaying shutdown on a dead endpoint.
        try
        {
            this.notifyExec.shutdownNow();
        }
        catch (Exception ignored)
        {
        }
        try
        {
            this.directServerExec.shutdownNow();
        }
        catch (Exception ignored)
        {
        }
        if (this.scarlet.shouldPersistOnShutdown())
            this.save();
        else
            LOG.info("Skipping mobile companion save after migration bundle import");
    }

    synchronized void ensureDirectServer()
    {
        if (!this.enabled.get())
            return;
        if (this.directServer != null)
            return;
        try
        {
            int requestedPort = DIRECT_PORT;
            HttpServer server = HttpServer.create(new InetSocketAddress("0.0.0.0", requestedPort), 16);
            server.createContext("/scarlet/mobile/health", this::handleDirectHealth);
            server.createContext("/scarlet/mobile/events", this::handleDirectEvents);
            server.createContext("/scarlet/mobile/pair", this::handleDirectPair);
            server.setExecutor(this.directServerExec);
            server.start();
            this.directServer = server;
            this.directServerPort = server.getAddress().getPort();
            LOG.info("Scarlet mobile direct LAN listener started on port {}", this.directServerPort);
        }
        catch (Exception ex)
        {
            LOG.warn("Exception starting Scarlet mobile direct LAN listener", ex);
        }
    }

    synchronized void stopDirectServer()
    {
        HttpServer server = this.directServer;
        this.directServer = null;
        if (server != null)
            server.stop(0);
        synchronized (this.directClients)
        {
            for (DirectClient client : this.directClients)
                client.close();
            this.directClients.clear();
        }
    }

    List<String> directEndpoints(String path)
    {
        if (!this.enabled.get())
            return Collections.emptyList();
        this.ensureDirectServer();
        int port = this.directServerPort;
        if (port <= 0)
            return Collections.emptyList();
        List<String> endpoints = new ArrayList<>();
        String token = this.state.directToken;
        for (String host : localIpv4Addresses())
            endpoints.add("http://" + host + ":" + port + "/scarlet/mobile/" + path + "?token=" + token);
        return endpoints;
    }

    void handleDirectHealth(HttpExchange exchange)
    {
        try
        {
            byte[] body = "{\"ok\":true,\"service\":\"scarlet-mobile-direct\"}".getBytes(StandardCharsets.UTF_8);
            Headers headers = exchange.getResponseHeaders();
            headers.set("Content-Type", "application/json; charset=utf-8");
            exchange.sendResponseHeaders(200, body.length);
            try (OutputStream out = exchange.getResponseBody())
            {
                out.write(body);
            }
        }
        catch (Exception ex)
        {
            LOG.debug("Exception handling mobile direct health request", ex);
        }
    }

    void handleDirectEvents(HttpExchange exchange)
    {
        String token = queryParam(exchange.getRequestURI().getRawQuery(), "token");
        if (!Objects.equals(token, this.state.directToken))
        {
            try
            {
                exchange.sendResponseHeaders(403, -1L);
            }
            catch (Exception ignored)
            {
            }
            finally
            {
                exchange.close();
            }
            return;
        }
        DirectClient client = null;
        try
        {
            Headers headers = exchange.getResponseHeaders();
            headers.set("Content-Type", "text/event-stream; charset=utf-8");
            headers.set("Cache-Control", "no-cache");
            headers.set("Connection", "keep-alive");
            exchange.sendResponseHeaders(200, 0L);
            client = new DirectClient(exchange);
            this.directClients.add(client);
            client.sendRaw("event: hello\ndata: {\"ok\":true}\n\n");
            // Occupies this handler thread for the lifetime of the connection, which is why
            // the direct server must not share Scarlet's general worker pool: every connected
            // phone would otherwise permanently consume one of its four threads.
            client.runWriter();
        }
        catch (Exception ex)
        {
            LOG.debug("Mobile direct event stream ended", ex);
        }
        finally
        {
            if (client != null)
            {
                this.directClients.remove(client);
                client.close();
            }
        }
    }

    void handleDirectPair(HttpExchange exchange)
    {
        String token = queryParam(exchange.getRequestURI().getRawQuery(), "token");
        int status = 200;
        String response = "{\"ok\":true}";
        try
        {
            if (!Objects.equals(token, this.state.directToken))
            {
                status = 403;
                response = "{\"ok\":false,\"error\":\"bad token\"}";
            }
            else if (!"POST".equalsIgnoreCase(exchange.getRequestMethod()))
            {
                status = 405;
                response = "{\"ok\":false,\"error\":\"method not allowed\"}";
            }
            else
            {
                JsonObject json;
                try (InputStreamReader reader = new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8))
                {
                    json = Scarlet.GSON.fromJson(reader, JsonObject.class);
                }
                Device device = Scarlet.GSON.fromJson(json.get("device"), Device.class);
                boolean ok = this.registerDevice(stringMember(json, "pairingId"), stringMember(json, "pairingSecret"), device);
                if (!ok)
                {
                    status = 400;
                    response = "{\"ok\":false,\"error\":\"pairing expired or invalid\"}";
                }
                else
                {
                    response = "{\"ok\":true,\"deviceId\":\"" + escapeJson(device.id) + "\"}";
                }
            }
        }
        catch (Exception ex)
        {
            LOG.warn("Exception handling mobile direct pairing", ex);
            status = 500;
            response = "{\"ok\":false,\"error\":\"internal error\"}";
        }
        finally
        {
            try
            {
                byte[] bytes = response.getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
                exchange.sendResponseHeaders(status, bytes.length);
                try (OutputStream out = exchange.getResponseBody())
                {
                    out.write(bytes);
                }
            }
            catch (Exception ignored)
            {
            }
            finally
            {
                exchange.close();
            }
        }
    }

    void info(String title, String message)
    {
        if (GraphicsEnvironment.isHeadless())
        {
            LOG.info("{}: {}", title, message);
            return;
        }
        this.scarlet.execModal.execute(() ->
        {
            Component parent = this.scarlet.ui == null ? null : this.scarlet.ui.getParentComponent();
            JOptionPane.showMessageDialog(parent, message, title, JOptionPane.INFORMATION_MESSAGE);
        });
    }

    static Severity severityOf(ScarletWatchedEntities.WatchedEntity watched)
    {
        if (watched == null)
            return Severity.INFO;
        if (watched.critical || watched.type == ScarletWatchedEntities.WatchedEntity.Type.MALICIOUS)
            return Severity.CRITICAL;
        if (watched.type == ScarletWatchedEntities.WatchedEntity.Type.NUISANCE || watched.priority > 0)
            return Severity.WARNING;
        return Severity.WATCH;
    }

    static Severity severityOf(ScarletWatchedGroups.WatchedGroup watched)
    {
        if (watched == null)
            return Severity.INFO;
        if (watched.critical || watched.type == ScarletWatchedGroups.WatchedGroup.Type.MALICIOUS)
            return Severity.CRITICAL;
        if (watched.type == ScarletWatchedGroups.WatchedGroup.Type.NUISANCE || watched.priority > 0)
            return Severity.WARNING;
        return Severity.WATCH;
    }

    static Severity severityForModeration(String auditType)
    {
        if (GroupAuditType.USER_BAN.id.equals(auditType) || GroupAuditType.MEMBER_REMOVE.id.equals(auditType))
            return Severity.CRITICAL;
        if (GroupAuditType.INSTANCE_KICK.id.equals(auditType) || GroupAuditType.INSTANCE_WARN.id.equals(auditType))
            return Severity.WARNING;
        if (GroupAuditType.USER_UNBAN.id.equals(auditType))
            return Severity.WATCH;
        return Severity.INFO;
    }

    static String nonBlank(String first, String fallback)
    {
        return clean(first) == null ? fallback : first;
    }

    static String clean(String value)
    {
        if (value == null)
            return null;
        value = value.trim();
        return value.isEmpty() ? null : value;
    }

    /** Formats how long ago an epoch-millis timestamp was, coarsely, for status text. */
    static String describeAge(long timestampMillis)
    {
        long seconds = Math.max(0L, (System.currentTimeMillis() - timestampMillis) / 1000L);
        if (seconds < 60L)
            return seconds + "s";
        long minutes = seconds / 60L;
        if (minutes < 60L)
            return minutes + "m";
        long hours = minutes / 60L;
        if (hours < 24L)
            return hours + "h";
        return (hours / 24L) + "d";
    }

    static String stringMember(JsonObject json, String member)
    {
        if (json == null || member == null || !json.has(member) || json.get(member).isJsonNull())
            return null;
        return json.get(member).getAsString();
    }

    static String escapeJson(String value)
    {
        if (value == null)
            return "";
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    static String urlEncode(String value)
    {
        try
        {
            return URLEncoder.encode(value, "UTF-8");
        }
        catch (Exception ex)
        {
            throw new IllegalStateException(ex);
        }
    }

    static String base64Url(byte[] bytes)
    {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    static byte[] signRsaSha256(String privateKeyPem, String value) throws Exception
    {
        String body = privateKeyPem
            .replace("-----BEGIN PRIVATE KEY-----", "")
            .replace("-----END PRIVATE KEY-----", "")
            .replace("\\n", "")
            .replace("\n", "")
            .replace("\r", "")
            .replace(" ", "")
            .trim();
        byte[] keyBytes = Base64.getDecoder().decode(body);
        PrivateKey key = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(keyBytes));
        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initSign(key);
        signature.update(value.getBytes(StandardCharsets.UTF_8));
        return signature.sign();
    }

    static String pairEndpointFor(String relayEndpoint)
    {
        relayEndpoint = clean(relayEndpoint);
        if (relayEndpoint == null)
            return null;
        try
        {
            URI uri = URI.create(relayEndpoint);
            String path = uri.getPath();
            if (path == null || path.isEmpty())
                path = "/";
            int slash = path.lastIndexOf('/');
            String pairPath = (slash < 0 ? "/" : path.substring(0, slash + 1)) + "pair";
            return new URI(uri.getScheme(), uri.getAuthority(), pairPath, null, null).toString();
        }
        catch (Exception ex)
        {
            return null;
        }
    }

    static String relayEventEndpointFor(String relayEndpoint, String instanceId)
    {
        relayEndpoint = clean(relayEndpoint);
        if (relayEndpoint == null || clean(instanceId) == null)
            return null;
        try
        {
            URI uri = URI.create(relayEndpoint);
            String path = uri.getPath();
            if (path == null || path.isEmpty())
                path = "/";
            int slash = path.lastIndexOf('/');
            String eventsPath = (slash < 0 ? "/" : path.substring(0, slash + 1)) + "events";
            // Auth is via Authorization header — instance ID in URL is not sensitive
            return new URI(uri.getScheme(), uri.getAuthority(), eventsPath, "instance=" + urlEncode(instanceId), null).toString();
        }
        catch (Exception ex)
        {
            return null;
        }
    }

    static List<String> localIpv4Addresses()
    {
        Set<String> hosts = new LinkedHashSet<>();
        try
        {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces != null && interfaces.hasMoreElements())
            {
                NetworkInterface nif = interfaces.nextElement();
                if (nif == null || !nif.isUp() || nif.isLoopback() || nif.isVirtual())
                    continue;
                Enumeration<InetAddress> addresses = nif.getInetAddresses();
                while (addresses.hasMoreElements())
                {
                    InetAddress address = addresses.nextElement();
                    if (address instanceof Inet4Address && !address.isLoopbackAddress() && !address.isLinkLocalAddress())
                        hosts.add(address.getHostAddress());
                }
            }
        }
        catch (Exception ex)
        {
            LOG.warn("Exception discovering LAN addresses for mobile pairing QR", ex);
        }
        if (hosts.isEmpty())
        {
            try
            {
                InetAddress local = InetAddress.getLocalHost();
                if (local instanceof Inet4Address && !local.isLoopbackAddress())
                    hosts.add(local.getHostAddress());
            }
            catch (Exception ignored)
            {
            }
        }
        return new ArrayList<>(hosts);
    }

    static String queryParam(String rawQuery, String name)
    {
        if (rawQuery == null || name == null)
            return null;
        for (String part : rawQuery.split("&"))
        {
            int eq = part.indexOf('=');
            String key = eq < 0 ? part : part.substring(0, eq);
            if (!Objects.equals(key, name))
                continue;
            return eq < 0 ? "" : part.substring(eq + 1);
        }
        return null;
    }

    static String randomToken(int bytes)
    {
        byte[] random = new byte[bytes];
        SECURE_RANDOM.nextBytes(random);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(random);
    }

    static String sha256(String value)
    {
        try
        {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
        }
        catch (Exception ex)
        {
            throw new IllegalStateException(ex);
        }
    }

    static String pairingSignaturePayload(String instanceId, String pairingId, String pairingSecret, String expiresAt)
    {
        return "scarlet-mobile-pairing"
            + "|" + String.valueOf(instanceId)
            + "|" + String.valueOf(pairingId)
            + "|" + String.valueOf(pairingSecret)
            + "|" + String.valueOf(expiresAt);
    }

    static String hmacSha256Hex(String key, String value)
    {
        try
        {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            byte[] bytes = mac.doFinal(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder(bytes.length * 2);
            for (byte b : bytes)
                out.append(String.format("%02x", b & 0xFF));
            return out.toString();
        }
        catch (Exception ex)
        {
            throw new IllegalStateException(ex);
        }
    }

    interface EventEditor
    {
        void edit(MobileEvent event);
    }

    static class State
    {
        String instanceId;
        String directToken;
        String relaySecret;
        /**
         * The relay endpoint the operator has accepted the disclosure for, or null if none.
         * Stored as the endpoint rather than a boolean so that changing the relay — including a
         * fork repointing it at a different host — re-prompts instead of silently inheriting an
         * old consent.
         */
        String relayConsentEndpoint;
        List<Device> devices = new ArrayList<>();
        List<PendingPairing> pendingPairings = new ArrayList<>();
    }

    static class FcmServiceAccount
    {
        String file;
        String projectId;
        String clientEmail;
        String privateKeyPem;
    }

    /**
     * A connected LAN server-sent-events client.
     * <p>
     * Sends are queued rather than written inline. A phone that leaves Wi-Fi range does not
     * send a TCP FIN, so the socket stays half-open and a direct {@code write} on it blocks
     * for as long as the kernel retransmits — tens of seconds. Previously that happened on
     * the thread dispatching the alert, so one out-of-range phone delayed or stalled every
     * other notification (and, because dispatch shared Scarlet's worker pool, audit polling
     * with it). Now {@link #send} only offers to a bounded queue and the connection's own
     * handler thread performs the blocking write.
     * <p>
     * The writer also emits a heartbeat comment whenever the queue is idle. Android and
     * carrier NAT silently drop idle TCP connections after roughly 30-60 seconds; without
     * traffic neither end notices, so alerts vanish into a dead socket. The heartbeat both
     * keeps the connection alive and surfaces a broken one within one interval.
     */
    static class DirectClient
    {
        /** Idle gap after which a heartbeat comment is written. */
        static final long HEARTBEAT_MILLIS = 15_000L;
        /** Queued frames tolerated before a client is considered too slow and dropped. */
        static final int QUEUE_CAPACITY = 64;

        DirectClient(HttpExchange exchange)
        {
            this.exchange = exchange;
            this.out = exchange.getResponseBody();
            this.closed = new CountDownLatch(1);
            this.queue = new ArrayBlockingQueue<>(QUEUE_CAPACITY);
            this.open = true;
            this.connectedAtMillis = System.currentTimeMillis();
        }

        final HttpExchange exchange;
        final OutputStream out;
        final CountDownLatch closed;
        final BlockingQueue<String> queue;
        final long connectedAtMillis;
        volatile boolean open;

        boolean send(String json)
        {
            return this.sendRaw("event: scarlet\ndata: " + json.replace("\n", "\\n") + "\n\n");
        }

        /** Queues a frame. Never blocks; returns false if the client is gone or too far behind. */
        boolean sendRaw(String data)
        {
            if (!this.open)
                return false;
            if (!this.queue.offer(data))
            {
                // The socket is not draining. Rather than let the backlog grow unbounded,
                // drop the client; the phone reconnects on its own retry loop.
                LOG.debug("Dropping mobile direct client that is not draining its event queue");
                this.close();
                return false;
            }
            return true;
        }

        /**
         * Blocking writer loop, run on the connection's own HTTP handler thread. Returns
         * once the client disconnects or a write fails.
         */
        void runWriter()
        {
            try
            {
                while (this.open)
                {
                    String data = this.queue.poll(HEARTBEAT_MILLIS, TimeUnit.MILLISECONDS);
                    // An idle poll means no alert was pending: send a comment frame instead.
                    // SSE comments are ignored by the client but still prove the socket lives.
                    if (data == null)
                        data = ": ping\n\n";
                    this.out.write(data.getBytes(StandardCharsets.UTF_8));
                    this.out.flush();
                }
            }
            catch (InterruptedException ex)
            {
                Thread.currentThread().interrupt();
            }
            catch (Exception ex)
            {
                LOG.debug("Mobile direct client write failed, closing stream", ex);
            }
            finally
            {
                this.close();
            }
        }

        void await() throws InterruptedException
        {
            this.closed.await();
        }

        void close()
        {
            this.open = false;
            this.closed.countDown();
            try
            {
                this.out.close();
            }
            catch (Exception ignored)
            {
            }
            try
            {
                this.exchange.close();
            }
            catch (Exception ignored)
            {
            }
        }
    }

    public static class Device
    {
        public String id;
        public String name;
        public String platform = "android";
        public boolean enabled = true;
        public String pushEndpoint;
        public String pushToken;
        public String authToken;
        public OffsetDateTime pairedAt;
        public OffsetDateTime lastSeenAt;
        public Map<String, Boolean> notificationTypes = new LinkedHashMap<>();

        // Delivery health. Transient (not persisted) — the useful question is whether this
        // device is receiving alerts in the current session, and a stale timestamp from a
        // previous run would be misleading. A phone that silently stops receiving used to be
        // completely invisible; these let the UI show it.
        public transient volatile long lastDeliveredAtMillis;
        public transient volatile long lastErrorAtMillis;
        public transient volatile String lastError;

        /** Human-readable delivery state for the UI, e.g. "Delivered 4s ago" or "Failed: HTTP 502". */
        public String deliveryStatus()
        {
            long delivered = this.lastDeliveredAtMillis, failed = this.lastErrorAtMillis;
            if (delivered <= 0L && failed <= 0L)
                return "No alerts sent yet";
            if (delivered >= failed)
                return "Delivered " + describeAge(delivered) + " ago";
            String error = this.lastError;
            return "Failed " + describeAge(failed) + " ago" + (error == null ? "" : ": " + error);
        }

        boolean wants(NotificationType type, boolean fallback)
        {
            if (type == null)
                return fallback;
            if (this.notificationTypes == null)
                return fallback;
            Boolean enabled = this.notificationTypes.get(type.id);
            return enabled == null ? fallback : enabled.booleanValue();
        }
    }

    static class PendingPairing
    {
        String pairingId;
        String secretHash;
        OffsetDateTime createdAt;
        OffsetDateTime expiresAt;
    }

    static class PairingPayload
    {
        String pairingId;
        OffsetDateTime expiresAt;
        String json;
    }

    public static class MobileEvent
    {
        public String id;
        public String type;
        public String typeTitle;
        public String severity;
        public String title;
        public String body;
        public OffsetDateTime timestamp;
        public String app;
        public String appVersion;
        public String instanceId;
        public String groupId;
        public String location;
        public String subjectId;
        public String subjectName;
        public JsonObject data;
    }

}
